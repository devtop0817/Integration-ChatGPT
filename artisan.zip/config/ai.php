<?php

return [

    'models' => [
        'text-davinci-003',
        'text-curie-001',
        'text-babbage-001',
        'text-ada-001'
    ],

];
