<?php

return [

    'software' => [
        'name'      => 'phpContent',
        'author'    => 'Lunatio',
        'url'       => 'https://lunatio.com',
        'version'   => '1.1.0'
    ]

];
